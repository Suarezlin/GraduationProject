package com.suarezlin.mapper;

import com.suarezlin.pojo.Videos;
import com.suarezlin.utils.MyMapper;

public interface VideosMapper extends MyMapper<Videos> {
}