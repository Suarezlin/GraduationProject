package com.suarezlin.mapper;

import com.suarezlin.pojo.UsersFans;
import com.suarezlin.utils.MyMapper;

public interface UsersFansMapper extends MyMapper<UsersFans> {
}