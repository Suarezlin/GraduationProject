package com.suarezlin.mapper;

import com.suarezlin.pojo.Comments;
import com.suarezlin.utils.MyMapper;

public interface CommentsMapper extends MyMapper<Comments> {
}