package com.suarezlin.mapper;

import com.suarezlin.pojo.Users;
import com.suarezlin.utils.MyMapper;

public interface UsersMapper extends MyMapper<Users> {
}