package com.suarezlin.mapper;

import com.suarezlin.pojo.UsersReport;
import com.suarezlin.utils.MyMapper;

public interface UsersReportMapper extends MyMapper<UsersReport> {
}