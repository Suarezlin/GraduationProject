package com.suarezlin.mapper;

import com.suarezlin.pojo.Bgm;
import com.suarezlin.utils.MyMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface BgmMapper extends MyMapper<Bgm> {
}