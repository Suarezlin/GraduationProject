package com.suarezlin.mapper;

import com.suarezlin.pojo.UserLikeVideos;
import com.suarezlin.utils.MyMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface UserLikeVideosMapper extends MyMapper<UserLikeVideos> {
}